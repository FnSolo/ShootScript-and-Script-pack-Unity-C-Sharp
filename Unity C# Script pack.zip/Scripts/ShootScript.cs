﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//not using UnityEngine.InputSystem;


//[AddComponentMenu("Nokobot/Modern Guns/Simple Shoot")]
public class ShootScript : MonoBehaviour
{
    [Header("1. Prefab References ")]
    public GameObject bulletPrefab;
    public GameObject casingPrefab;
    public GameObject muzzleFlashPrefab;

    [Header("2. Location Refrences ")]
    [SerializeField] private Animator gunAnimator;
    [SerializeField] private Transform barrelLocation;
    [SerializeField] private Transform casingExitLocation;
    [SerializeField] private Transform muzzleLocation;
    [SerializeField] private Transform cameraRecoil;

    [Header("3. Settings")]
    [Tooltip("Specify time to destory the casing object")][SerializeField] private float destroyTimer = 2f;
    [Tooltip("Bullet Speed")][SerializeField] private float shotPower = 500f;
    [Tooltip("Casing Ejection Speed, set low on low weights")][SerializeField] private float ejectPower = 1.5f;

    [Header("Rate of fire")]
    [Tooltip("Time beetwen shots-fire animation")][SerializeField] private float interval = 0.1f;
    [Tooltip("Time already passed")][SerializeField] private float timer = 1f;
    [Header("Time between shot sounds")][SerializeField] private float cutTimer, cut = 2.328f;

    [Header("Minigun mode")]
    [Tooltip("Cut immediately on Up, useful for high rate & looped")][SerializeField] private bool minigunMode = true;
    [Tooltip("Allow attack on spin")][SerializeField] private bool mouse1Spin = false;

    [Header("4. Recoil, X's inverted")]
    [Tooltip("Uses * Time.deltaTime to smooth")][SerializeField] private float rotateCameraX = 500;
    [Tooltip("Uses * Time.deltaTime to smooth")][SerializeField] private float rotateCameraY = 11;
    [Tooltip("Uses * Time.deltaTime to smooth")][SerializeField] private float rotateCameraZ = 111;
    [Tooltip("Assings new local quaternion, then resets")][SerializeField] private float shakeBarrelX = 0.05f, shakeBarrelBothY = 0.05f;
    Quaternion resetRecoil;

    [Header("5. Animation bools")]
    [SerializeField] string Fire = "Fire";
    [SerializeField] private string Spin = "Spin";

    [Header("6. Sounds, cuts is in voids")]
    [Tooltip("By default pitch randoms -5%")][SerializeField] AudioSource spinUp;
    [SerializeField] AudioSource spinFinish;

    [Header("Randomize main sound")]
    [Tooltip("Disabled in minigun mode")][SerializeField] float randomizeUp = 0.00f;
    [SerializeField] float randomizeDown = 0.05f;
    [SerializeField] float origPitch = 1;
    // [SerializeField] float cutSpin = 0.967f, cutSpinTime;


    private new AudioSource audio;

    void Start()
    {
        if (barrelLocation == null)
            barrelLocation = transform;

        if (gunAnimator == null)
            gunAnimator = GetComponentInChildren<Animator>();
        audio = GetComponent<AudioSource>();
    }

    void Update()
    {
        //rate of fire
        if (timer < interval)
        {
            timer += Time.deltaTime;
        }

        if (mouse1Spin)
        {
            // if (Input.GetButtonDown("Fire2") && !Input.GetButton("Fire1"))
            // {
            //     spinUp.PlayOneShot(spinUp.clip);
            // }
            if (Input.GetButton("Fire2") && !Input.GetButton("Fire1"))
            {

                gunAnimator.SetBool(Spin, true);

                // if (cutSpinTime < cutSpin)
                // {
                //     cutSpinTime += Time.deltaTime;
                // }
                // else
                // {
                //     spinUp.PlayOneShot(spinUp.clip);
                //     cutSpinTime = 0;
                // }
                //gunAnimator.SetBool(Fire, true);

            }

            if (Input.GetButtonUp("Fire2"))
            {
                gunAnimator.SetBool(Spin, false);
                // spinUp.Stop();
                // spinFinish.Play();
            }

        }

        if (Input.GetButtonDown("Fire1") && timer >= interval)
        {

            cutTimer = 99;

            barrelLocation.localRotation = resetRecoil;

            resetRecoil = barrelLocation.localRotation;

        }

        if (cutTimer <= cut)
        {
            cutTimer += Time.deltaTime;
        }

        //If you want a different input, change it here
        if (Input.GetButton("Fire1") && timer >= interval)
        {
            //shot made, reset rate of fire timer
            timer = 0;
            //Calls animation on the gun that has the relevant animation events that will fire
            gunAnimator.SetBool(Fire, true);
            //recoil is in Shoot()
        }


        if (Input.GetButtonUp("Fire1"))
        {
            gunAnimator.SetBool(Fire, false);

            //Minigun mode, cut shoot sound on Up
            if (minigunMode)
            {
                audio.Stop();
            }

            barrelLocation.localRotation = resetRecoil;
        }

    }

    //Cut sound on function for robustness and both modes, starts spinFinish audio, stops other
    void CutMainSound_PlayFinish()
    {
        audio.Stop();

        if (mouse1Spin)
        {
            spinUp.Stop();
            spinFinish.Play();
        }
    }

    //spinUp PlayOneShot func
    void SpinUp()
    {
        spinUp.pitch = Random.Range(0.95f, 1.0f);
        spinUp.PlayOneShot(spinUp.clip);
        //spinUp.Play();
    }
    //cut spinUp sound for extra control, if needed
    void SpinUpStop()
    {
        spinUp.Stop();
    }
    //Extra, cut main sound, useful if Shoot() is not called on 1st animation frame
    void CutMainSound()
    {
        audio.Stop();
    }

    //This function creates the bullet behavior
    void Shoot()
    {
        SpinUpStop();
        //sound
        if (minigunMode)
        {
            if (cutTimer >= cut)
            {
                cutTimer = 0;
                audio.pitch = Random.Range(origPitch - randomizeDown, origPitch);
                audio.PlayOneShot(audio.clip);
            }
        }
        else
        {
            audio.pitch = Random.Range(origPitch - randomizeDown, origPitch + randomizeUp);
            audio.PlayOneShot(audio.clip);
        }


        //recoil
        barrelLocation.localRotation = new Quaternion(Random.Range(0f, -shakeBarrelX), Random.Range(-shakeBarrelBothY, shakeBarrelBothY), barrelLocation.localRotation.z, barrelLocation.localRotation.w);
        cameraRecoil.Rotate(-rotateCameraX * Time.deltaTime, rotateCameraY * Time.deltaTime, rotateCameraZ * Time.deltaTime);

        if (muzzleFlashPrefab)
        {
            //Create the muzzle flash
            GameObject tempFlash;
            tempFlash = Instantiate(muzzleFlashPrefab, muzzleLocation.position, muzzleLocation.rotation);

            //Destroy the muzzle flash effect
            Destroy(tempFlash, destroyTimer);

        }

        //cancels if there's no bullet prefeb
        if (!bulletPrefab)
        { return; }

        // Create a bullet and add force on it in direction of the barrel
        Instantiate(bulletPrefab, barrelLocation.position, barrelLocation.rotation).GetComponent<Rigidbody>().AddForce(barrelLocation.forward * shotPower);

        //recoil reset
        barrelLocation.localRotation = resetRecoil;

    }

    //This function creates a casing at the ejection slot
    void CasingRelease()
    {
        //Cancels function if ejection slot hasn't been set or there's no casing
        if (!casingExitLocation || !casingPrefab)
        { return; }

        //Create the casing
        GameObject tempCasing;
        tempCasing = Instantiate(casingPrefab, casingExitLocation.position, casingExitLocation.rotation) as GameObject;
        //Add force on casing to push it out
        tempCasing.GetComponent<Rigidbody>().AddExplosionForce(Random.Range(ejectPower * 0.7f, ejectPower), (casingExitLocation.position - casingExitLocation.right * 0.3f - casingExitLocation.up * 0.6f), 1f);
        //Add torque to make casing spin in random direction
        tempCasing.GetComponent<Rigidbody>().AddTorque(new Vector3(0, Random.Range(100f, 500f), Random.Range(100f, 1000f)), ForceMode.Impulse);

        //Destroy casing after X seconds
        Destroy(tempCasing, destroyTimer);
    }

}
