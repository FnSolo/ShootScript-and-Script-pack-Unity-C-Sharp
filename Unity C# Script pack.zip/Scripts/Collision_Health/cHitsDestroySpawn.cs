using UnityEngine;



public class cHitsDestroySpawn : MonoBehaviour
{
    [Header("Position syncer")]
    [Tooltip("Be sure your prefab suits object in '0' Transforms")] public Transform GetPos;
    [Header("Debris")]
    [Tooltip("Be sure your prefab suits object in '0' Transforms")] public GameObject Parts;
    
    [Tooltip("Loot inside")] [SerializeField] private GameObject Loot;
    //private Vector3 position;
    //private Quaternion rotation;
    private int Hits;
    [Header("Hit Points")]
    [Tooltip("Collides until destroy")] public int MaxCollisions = 1;
    
    private void OnCollisionEnter(Collision collision)
    {
    Hits++;
    if(Hits==MaxCollisions)
        {
            //position = GetPos.transform.position;
            //rotation = GetPos.transform.rotation;
            Destroy(gameObject);
            Instantiate(Parts, GetPos.position, GetPos.rotation);
            Instantiate(Loot, GetPos.position, GetPos.rotation);
       
        }
    }
}
