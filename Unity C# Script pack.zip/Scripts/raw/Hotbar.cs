using UnityEngine;

public class Hotbar : MonoBehaviour
{
    //[Header("Get transforms")] can be useful to instant effect on unholster
    //public Transform holder;
    [Header("Swap delay")]
    [SerializeField] private float timer, interval = 0.1f;
    [Header("Hotbar")]
    public GameObject item1;
    public GameObject item2;
    public GameObject item3;
    private int chosen;
    // Start is called before the first frame update, leave for checkbox
    void Start()
    {
        
    }

    private void Update()
    {
        if(timer<interval){
        timer += Time.deltaTime;
        }
        

        //Item 1 draw
        if(Input.GetButtonDown("1") && chosen!=1 && timer>interval)//&&chosen!=2)
        {
            timer = 0;
            item1.SetActive(true);
            //set inactive other items on draw
            item2.SetActive(false);item3.SetActive(false);

            chosen = 1;
        }
        //holster chosen 
        if(Input.GetButtonDown("1") && chosen==1 && timer>interval)
        {
            timer = 0;
            chosen = 0;

            item1.SetActive(false);
        }
        
        //Item 2 draw
        if(Input.GetButtonDown("2") && chosen!=2 && timer>interval)//)
        {
            timer = 0;
            item2.SetActive(true);
            //set inactive other items on draw
            item1.SetActive(false);item3.SetActive(false);

            chosen = 2;
        }
        //holster chosen 
        if(Input.GetButtonDown("2") && chosen==2 && timer>interval)
        {
            timer = 0;
            chosen = 0;

            item2.SetActive(false);
        }

        //Item 3 draw
        if(Input.GetButtonDown("3") && chosen!=3 && timer>interval)//)
        {
            timer = 0;
            item3.SetActive(true);
            //set inactive other items on draw
            item1.SetActive(false);item2.SetActive(false);

            chosen = 3;
        }
        //holster chosen 
        if(Input.GetButtonDown("3") && chosen==3 && timer>interval)
        {
            timer = 0;
            chosen = 0;

            item3.SetActive(false);
        }

        
        
    }
}
