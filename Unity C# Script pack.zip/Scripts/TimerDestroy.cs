using UnityEngine;

public class TimerDestroy : MonoBehaviour
{
    [SerializeField] private float interval = 1f;
    void Start()
    {
        Destroy(gameObject, interval);
    }

}
