using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProceduralXZ : MonoBehaviour
{
    public GameObject roomPrefab;
    GameObject[] rooms;
    public bool lookPos = true;
    [Header("Central raycaster for connectors, cast rays 4 sides, dist = size / 2")]
    [Header("Connectors to disable")]
    public GameObject[] connectors;

    public GameObject disconnector;

    [Header("Raycast calc floor")]
    public Transform squareFloor;
    float distX, distZ;
    [Header("Rooms")]
    public int roomAmount;

    public int xRange = 5, /*yRange = 10,*/ zRange = 5;

    public static int roomsStatic;

    //public int stop;

    private int randomID;
    private Vector3 xz;

    string ID;

    public bool px = true, pz = true, _x = true, _z = true;


    // Start is called before the first frame update
    void Start()
    {
        xz = gameObject.transform.position;



        for (int i = 0; i < connectors.Length; i++)
                {
                    connectors[i].SetActive(false);
                }
        rooms = new GameObject[roomAmount];
        //stop = rooms.Length;
        randomID = Random.Range(0,int.MaxValue);
        ID = randomID.ToString();

        // rooms = Instantiate(roomPrefab, new Vector3(0, -10, 0), Quaternion.identity, transform);
        for (int i = 0; i < rooms.Length; i++)
                {
                    rooms[i] = Instantiate(roomPrefab, new Vector3(0, -10, 0), Quaternion.identity, transform.parent);
                    
                    rooms[i].name += randomID.ToString();

                    Debug.Log(rooms[i].name);
                }
       
        //Debug.Log(distX);

        
    }

    // Update is called once per frame
    void Update()
    {
        distX = squareFloor.lossyScale.x / 2;
        distZ = squareFloor.lossyScale.z / 2;
        
        

        if (lookPos==true)
        {
            // rooms.transform.position = new Vector3(Random.Range(-xRange, xRange), 0, Random.Range(-zRange, zRange));
            for (int i = 0; i < rooms.Length; i++)
                {   
                    xz += new Vector3(Random.Range(-xRange, xRange), 0, Random.Range(-zRange, zRange));
                    rooms[i].transform.position = xz;
                    xz = gameObject.transform.position;

                }
        }

        if (_x==true)
        {
            RaycastX(-1,0,0);
        }
         
        if (px==true)
        {
            RaycastX(1,0,0);
        }
         
        if (_z == true)
        {
            RaycastZ(0,0,-1);
        }
        
        if (pz == true)
        {
            RaycastZ(0,0,1);
        }
        
        
        
    }

    private void RaycastX(float x, float y, float z)
    {
        RaycastHit ray;
    
        if (Physics.Raycast(transform.position, transform.TransformDirection(x,y,z), out ray, distX * 1.01f))
        {
            Debug.DrawRay(transform.position, transform.TransformDirection(x,y,z) * ray.distance, Color.yellow);
            
            if (ray.collider.tag == "Procedural Connector" && ray.distance >= distX * 0.99 
            /*&& ray.collider.transform.parent.name.Contains(ID)*/ && rooms[0].transform.position != gameObject.transform.position)
            {

                lookPos = false;
                Instantiate(disconnector, ray.point, ray.transform.rotation);



                Debug.DrawRay(transform.position, transform.TransformDirection(x,y,z) * ray.distance, Color.magenta);

                for (int i = 0; i < connectors.Length; i++)
                {
                    connectors[i].SetActive(true);
                }

                if (x == -1)
                {
                    _x = false;
                }
                if (x == 1)
                {
                    px = false;
                }
                if (z == -1)
                {
                    _z = false;
                }
                if (z == 1)
                {
                    pz = false;
                }

            }
            else
            {
            Debug.DrawRay(transform.position, transform.TransformDirection(x,y,z) * distX, Color.white);

            }

        }
        
    }

    private void RaycastZ(float x, float y, float z)
    {
        RaycastHit ray;

        if (Physics.Raycast(transform.position, transform.TransformDirection(x,y,z), out ray, distZ * 1.01f))
        {
            Debug.DrawRay(transform.position, transform.TransformDirection(x,y,z) * ray.distance, Color.yellow);
            
            if (ray.collider.tag == "Procedural Connector" && ray.distance >= distZ * 0.99
            /*&& ray.collider.transform.parent.name.Contains(ID)*/ && rooms[0].transform.position != gameObject.transform.position)
            {

                lookPos = false;
                Instantiate(disconnector, ray.point,ray.transform.rotation);

                

                Debug.DrawRay(transform.position, transform.TransformDirection(x,y,z) * ray.distance, Color.magenta);

                for (int i = 0; i < connectors.Length; i++)
                {
                    connectors[i].SetActive(true);
                }
                
                if (x == -1)
                {
                    _x = false;
                }
                if (x == 1)
                {
                    px = false;
                }
                if (z == -1)
                {
                    _z = false;
                }
                if (z == 1)
                {
                    pz = false;
                }

            }
            else
            {
                Debug.DrawRay(transform.position, transform.TransformDirection(x,y,z) * distZ, Color.white);

            }        

        }


        
    }

}
