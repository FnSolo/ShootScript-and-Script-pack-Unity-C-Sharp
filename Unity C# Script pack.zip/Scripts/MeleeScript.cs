using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeleeScript : MonoBehaviour
{
    [Header("▶ Damage modes ")]
    public Transform raySource;

    [Header("Trigger")]
    public Collider damageTrigger;

    [Header("Prefab")]
    public GameObject rayPrefab;

    [Header("Hitscan")]
    [Tooltip("Disables rayPrefab")] public bool hitScan = true;
    public int hitScanLayer = 3;
    public float forceAdd = 100f;
    public GameObject decal;
    public float decalTime = 12;

    [Header("▶ Settings")]
    public float range = 1.25f;
    public int layersExcept = 1;


    [Header("▶ Animation")]
    public KeyCode key = KeyCode.Mouse0;
    public KeyCode runKey = KeyCode.LeftShift;
    public Animator animator;
    [Header("Bools")]
    public string Run = "Run";
    public string Swing = "Swing";

    [Header("▶ Sound")]

    [Header("Swing")]
    [Tooltip("Can be none")] public AudioSource sound;
    [Tooltip("Pitch random -+")][Range(0, 3)] public float randomize = 0.1f, orig = 1;

    [Header("Hitscan")]
    public AudioSource hitScanSound;
    [Tooltip("Pitch random -+")][Range(0, 3)] public float randomize2 = 0.5f, orig2 = 1;

    //non-inspector

    //


    void Start()
    {

    }

    void Update()
    {

        if (Input.GetKey(key) && !Input.GetKey(runKey))
        {

            if (animator)
            {
                animator.SetBool(Swing, true);
            }

        }

        if (Input.GetKey(runKey))
        {
            if (animator)
            {
                animator.SetBool(Run, true);
            }
        }
        else
        {
            if (animator)
            {
                animator.SetBool(Run, false);
            }
        }

    }

    void Stop()
    {
        animator.SetBool(Swing, false);
        if (damageTrigger)
        {
            damageTrigger.enabled = false;
        }
    }

    void StartAttack()
    {

        if (sound)
        {
            sound.pitch = Random.Range(orig - randomize, orig + randomize);
            sound.PlayOneShot(sound.clip);
        }

        if (rayPrefab)
        {
            // Bit shift the index of the layer <<"" to get a bit mask
            int layerMask = 1 << layersExcept;

            // This would cast rays only against colliders in layer <<"".
            // But instead we want to collide against everything except layer <<"". The ~ operator does this, it inverts a bitmask.
            layerMask = ~layerMask;

            RaycastHit hit;
            // Does the ray intersect any objects excluding the player layer
            if (Physics.Raycast(raySource.position, raySource.TransformDirection(Vector3.forward), out hit, range, layerMask))
            {
                if (hitScan == true)
                {
                    var Decal = Instantiate(decal, hit.point, raySource.rotation, hit.collider.transform);
                    Destroy(Decal, decalTime);

                    if (hit.collider.gameObject.layer == 3)
                    {

                        hit.collider.gameObject.GetComponentInParent<Mineable>().Damage();
                        if (hitScanSound)
                        {

                            hitScanSound.pitch = Random.Range(orig2 - randomize2, orig2 + randomize2);

                            hitScanSound.PlayOneShot(hitScanSound.clip);



                        }

                        if (hit.rigidbody)
                        {
                            hit.rigidbody.AddForce(raySource.forward * forceAdd);

                            hitScanSound.pitch = Random.Range(orig2 - randomize2, orig2 + randomize2);

                            hitScanSound.PlayOneShot(hitScanSound.clip);
                        }

                    }
                    else
                    {
                        hitScanSound.pitch = Random.Range(orig2 - randomize2, orig2);

                        hitScanSound.PlayOneShot(hitScanSound.clip);

                        if (hit.rigidbody)
                        {
                            hit.rigidbody.AddForce(raySource.forward * forceAdd);
                        }

                    }

                }
                else
                {
                    Instantiate(rayPrefab, raySource.position, raySource.rotation).GetComponent<Rigidbody>().AddForce(raySource.forward * 1111f);
                }



                Debug.DrawRay(raySource.position, raySource.TransformDirection(Vector3.forward) * hit.distance, Color.green, 0.1f);
            }
            else
            {
                Debug.DrawRay(raySource.position, raySource.TransformDirection(Vector3.forward) * range, Color.red, 0.1f);
            }

        }

        if (damageTrigger)
        {
            damageTrigger.enabled = true;
        }


    }
    void ColliderOff()
    {
        if (damageTrigger)
        {
            damageTrigger.enabled = false;
        }

    }
}
