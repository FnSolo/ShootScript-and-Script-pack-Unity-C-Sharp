using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Simple
{
    public class GetLocalRotatation : MonoBehaviour
    {
        public Transform get;
        

        void Start()
        {

        }

        void Update()
        {
            transform.localRotation = get.localRotation;
            // Vector3 targetPostition = new Vector3(get.position.x, this.transform.position.y, get.position.z);
            // this.transform.LookAt(targetPostition);
            //gameObject.transform.position = get.transform.position;
        }
    }

}

