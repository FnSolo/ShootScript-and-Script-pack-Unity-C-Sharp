using UnityEngine;

public class InstantiatePrefab : MonoBehaviour
{

    public GameObject Prefab;
    [Header("Get transforms")]
    [SerializeField] private Transform Location;

    private void Start() 
    {
        Instantiate(Prefab, Location.position, Location.rotation);
    }

}
