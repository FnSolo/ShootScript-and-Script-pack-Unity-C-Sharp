using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Simple
{
    public class Flashlight : MonoBehaviour
    {
        public GameObject spotlight;
        public KeyCode key = KeyCode.F;
        public AudioSource sound;
        [Header("Randomize limits")]
        [Range(0.01f, 6)]public float min = 0.95f, max = 1.05f;

        void Start()
        {

        }

        void Update()
        {
            if (Input.GetKeyDown(key) && spotlight.activeInHierarchy == false)
            {
                spotlight.SetActive(true);

                sound.pitch = Random.Range(min, max);
                sound.PlayOneShot(sound.clip);
            }
            else if (Input.GetKeyDown(key) && spotlight.activeSelf == true)
            {
                spotlight.SetActive(false);

                sound.pitch = Random.Range(min, max);
                sound.PlayOneShot(sound.clip);
            }
        }

    }
}

