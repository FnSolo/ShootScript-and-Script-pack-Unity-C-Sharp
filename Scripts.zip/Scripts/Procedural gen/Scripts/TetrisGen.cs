using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TetrisGen : MonoBehaviour
{   
    [Header("Must have isKinematic on collision script")]
    public GameObject[] gen;
    public Transform shooter;

    public int shotPower = 99999;
    public int distance;

    [Header("Enter x scale of object here")]
    public float Step = 1.1f;

    float timer; int amount;

    

    
    // Start is called before the first frame update
    void Start()
    {
        //amount = gen.Length;

        // for (int i = 0; i < gen.Length; i++)
        // {
        //     timer=0;
        //     shooter.position = new Vector3(Random.Range(0, distance), 0, 0);
        //     Instantiate(gen[i], shooter.transform.position, Quaternion.identity).GetComponent<Rigidbody>().AddForce(shooter.forward * shotPower);

        //     if (timer<0.5f)
        //     {
        //         timer += Time.deltaTime;
        //     }
        // }
    }

    private void Update() 
    {
        if (timer<0.5f)
        {
            timer+= Time.deltaTime;
        }
        else{
            timer=0;
        }

        if (timer==0 && amount != gen.Length)
        {
            amount++;
            shooter.position = new Vector3(GetRandomHealth(), 0, 0);
            Instantiate(gen[amount], shooter.transform.position, Quaternion.identity).GetComponent<Rigidbody>().AddForce(shooter.forward * shotPower);
        }

    }

    float GetRandomHealth () {
     float randomHealth = Random.Range(0, distance);
     float numSteps = Mathf.Floor (randomHealth / Step);
     float adjustedHealth = numSteps * Step;
 
     return adjustedHealth;
    }
    // private IEnumerator Countdown()
    // {

    //  float duration = 0.5f; // seconds you can change this 
    //  //to whatever you want
    //  float normalizedTime = 0;
    //  while(normalizedTime <= 1f)
    //  {
    //      countdownImage.fillAmount = normalizedTime;
    //      normalizedTime += Time.deltaTime / duration;
    //      yield return null;
    //  }

    // }
}
