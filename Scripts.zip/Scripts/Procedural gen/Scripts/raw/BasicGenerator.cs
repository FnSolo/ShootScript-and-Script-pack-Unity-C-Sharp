using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicGenerator : MonoBehaviour
{
    [Header("Objects to place")]
    public GameObject[] rooms;
    private bool[] done;

    [Header("Size of grid, be sure its enough")]
    public int step = 11;
    private Transform[] occupied;
    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < rooms.Length; i++)
                {
                    rooms[i] = Instantiate(rooms[i], new Vector3Int(Random.Range(-step,step), 0, Random.Range(-step,step)), Quaternion.identity);
                }
    }


    void Update()
    {
        // for (int i = 0; i < rooms.Length; i++)
        // {

        //     if (occupied[i].transform.position!=rooms[i].transform.position)
        //     {
        //          occupied[i].transform.position = rooms[i].transform.position;
        //     }
            
        //     if(occupied[i].transform.position==rooms[i].transform.position)
        //     {
        //         rooms[i].transform.position = new Vector3Int(Random.Range(-2,2), 0, Random.Range(-2,2));
        //     }
           
            
        // }
        int checkOne = Random.Range(0,rooms.Length);
        int checkTwo = Random.Range(0,rooms.Length);
        if(rooms[checkOne].transform.position==rooms[checkTwo].transform.position && done[checkOne]!= true)
        {
            rooms[checkOne].transform.position = new Vector3Int(Random.Range(-step,step), 0, Random.Range(-step,step));
            done[checkOne] = true;
        }
        
    }
}
