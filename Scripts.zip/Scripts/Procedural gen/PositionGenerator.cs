using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PositionGenerator : MonoBehaviour
{
    [Header("Objects to place")]
    public GameObject[] rooms;

    [Header("Grid size, make sure its enough")]
    public float distance = 11;

    [Header("Enter scales here")]
    public float Xstep = 2.2f; 
    public float Ystep = 0; 
    public float Zstep = 2.2f;
    public bool XZBothSides = true, YBothHeights = false;

    void Start()
    {
        for (int i = 0; i < rooms.Length; i++)
                {
                    rooms[i] = Instantiate(rooms[i], new Vector3(RandomStepX(), RandomStepY(), RandomStepZ()), Quaternion.identity);
                }

                
    }


    void Update()
    {
           
        FindPos();
        Debug.DrawRay(transform.position, Vector3.forward * distance,Color.white);
        
    }

    private void FindPos()
    {
        int checkOne = Random.Range(0,rooms.Length);
        int checkTwo = Random.Range(0,rooms.Length);

        if(rooms[checkOne].transform.position==rooms[checkTwo].transform.position && rooms[checkOne]!=rooms[checkTwo])
        {
            rooms[checkOne].transform.position = new Vector3(RandomStepX(), RandomStepY(), RandomStepZ());
        }
    }

    float RandomStepX () 
    {

        if (XZBothSides==false)
        {
            
            if (Xstep!=0)
            {
                float random = Random.Range(0, distance);
                float numSteps = Mathf.Floor (random / Xstep);
                float adjustedRandom = numSteps * Xstep;
            
                return adjustedRandom;
            }
            else
            {
                return 0;
            }

        }
        else
        {
            if (Xstep!=0)
            {
                float random = Random.Range(-distance, distance);
                float numSteps = Mathf.Floor (random / Xstep);
                float adjustedRandom = numSteps * Xstep;
            
                return adjustedRandom;
            }
            else
            {
                return 0;
            }
        }

    }

    float RandomStepY () 
    {
        
        if (YBothHeights==false)
        {
            
            if (Ystep!=0)
            {
                float random = Random.Range(0, distance);
                float numSteps = Mathf.Floor (random / Ystep);
                float adjustedRandom = numSteps * Ystep;
            
                return adjustedRandom;
            }
            else
            {
                return 0;
            }

        }
        else
        {
            if (Ystep!=0)
            {
                float random = Random.Range(-distance, distance);
                float numSteps = Mathf.Floor (random / Ystep);
                float adjustedRandom = numSteps * Ystep;
            
                return adjustedRandom;
            }
            else
            {
                return 0;
            }
        }
     
    }

    float RandomStepZ () 
    {

        if (XZBothSides==false)
        {
            
            if (Zstep!=0)
            {
                float random = Random.Range(0, distance);
                float numSteps = Mathf.Floor (random / Zstep);
                float adjustedRandom = numSteps * Zstep;
            
                return adjustedRandom;
            }
            else
            {
                return 0;
            }

        }
        else
        {
            if (Zstep!=0)
            {
                float random = Random.Range(-distance, distance);
                float numSteps = Mathf.Floor (random / Zstep);
                float adjustedRandom = numSteps * Zstep;
            
                return adjustedRandom;
            }
            else
            {
                return 0;
            }
        }

    }

}
