using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    [Header("Health")]
    [SerializeField] private int Health = 100;
    [SerializeField] private int damage = 25;
    public GameObject bloodPrefab;
    public GameObject deadPrefab;
    [SerializeField] private Transform bodyLocation;
    [Tooltip("Tag name for damage intake")][SerializeField] private string damageFrom = "Bullet";

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //health check
        if (Health <= 0)
        {
            
            Instantiate(deadPrefab, bodyLocation.position, bodyLocation.rotation);
            // if (transform.parent.gameObject)
            // {
            //     Destroy(transform.parent.gameObject);
            // }
            // else
            // {
                Destroy(gameObject);
            // }
            
        }
        
    }

    //Damage intake, take damage from gameobject with collider tag that contains string damageFrom
    void OnCollisionEnter(Collision col)
    {
		if(col.collider.tag == damageFrom)
        {
			Health -= damage;
			GameObject blood = Instantiate(bloodPrefab, col.collider.transform.position, col.collider.transform.rotation) as GameObject;
			Destroy(blood, 12);
            Debug.Log("Player Health is: " + Health);
		}
	}
    //

}
