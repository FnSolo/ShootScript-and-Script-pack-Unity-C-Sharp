using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SUPERCharacter;

namespace Players // "Player" is occupied
{
    public class MovementAnimator : MonoBehaviour
    {
        public Animator Legs;
        public KeyCode crouchKey = KeyCode.LeftControl;
        public KeyCode runKey = KeyCode.LeftShift;
        public string Run = "Run", Backrun = "Backrun", Walk = "Walk", Backwalk = "Backwalk", Jump = "Jump", Crouch = "Crouch";
        public string animFloat = "Blend";
        public AudioSource stepSound, jumpSound;

        [Header("Randomize")]
        public float pitchMin = 0.95f, pitchMax = 1.05f;
        float clock;
        Animation anim;
        public SUPERCharacterAIO Controller;

        void Start()
        {
            anim = GetComponent<Animation>();
        }

        void Update()
        {
            clock += Time.deltaTime;
            if (Input.GetAxis("Vertical") > 0)
            {

                if (Input.GetKey(runKey))
                {
                    Legs.SetBool(Run, true);
                    Legs.SetBool(Backrun, false);
                }
                else
                {
                    Legs.SetBool(Walk, true);
                    Legs.SetBool(Backwalk, false);
                    Legs.SetBool(Run, false);
                    Legs.SetBool(Backrun, false);
                }
            }
            else if (Input.GetAxis("Vertical") == 0)
            {
                Legs.SetBool(Backwalk, false);
                Legs.SetBool(Walk, false);
                Legs.SetBool(Run, false);
                Legs.SetBool(Backrun, false);
            }
            else
            {
                if (Input.GetKey(runKey))
                {
                    Legs.SetBool(Run, false);
                    Legs.SetBool(Backrun, true);
                }
                else
                {
                    Legs.SetBool(Walk, false);
                    Legs.SetBool(Backwalk, true);
                    Legs.SetBool(Run, false);
                    Legs.SetBool(Backrun, false);
                }
            }



            if (Input.GetButtonDown("Jump") && !Legs.GetBool(Jump) && Controller.currentGroundInfo.isInContactWithGround)
            {
                //Legs.SetFloat(Blend, -1);
                Legs.SetBool(Jump, true);
                jumpSound.pitch = Random.Range(pitchMin, pitchMax);
                jumpSound.PlayOneShot(jumpSound.clip);
            }


            if (Input.GetKeyDown(crouchKey) && Controller.currentStance != Stances.Crouching)
            {
                Legs.SetBool(Crouch, true);
            }
            else if (Input.GetKeyDown(crouchKey) && Controller.currentStance == Stances.Crouching)
            {
                Legs.SetBool(Crouch, false);
            }
        }

        void StepSound()
        {
            if (stepSound)
            {
                stepSound.pitch = Random.Range(pitchMin, pitchMax);
                stepSound.PlayOneShot(stepSound.clip);
            }
        }

        void JumpFalse()
        {
            Legs.SetBool(Jump, false);
        }

        void StopAll()
        {
            anim.Stop();
        }

    }
}

