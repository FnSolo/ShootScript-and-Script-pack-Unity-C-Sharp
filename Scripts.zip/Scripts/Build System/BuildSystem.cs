using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

namespace XEntity.InventoryItemSystem
{

    public class BuildSystem : MonoBehaviour
    {
        //public static int dataToSlot;
        public TextMeshPro counter;
        public int count;
        public static int spent;
        public Transform raySource;
        public float range = 5f;

        [Header("What layer to ignore")]
        public int layersExcept = 1;
        public static Transform HitLocation;
        [Header("Uses hold")]
        public KeyCode BuildButton = KeyCode.Mouse1;

        [Header("Use preview prefab from scene")]
        public GameObject PreviewBlock;

        [Header("Building block")]
        public GameObject Block;
        [Tooltip("Time beetwen placing")][SerializeField] private float timer, interval = 0.2f;

        //non-inspector
        private GameObject PreviewClone;
        private Color originalColor;

        private GameObject badPlace;

        //

        public void Start()
        {
            //counter.text = count.ToString();
            //spent = count;

            //creates preview block
            PreviewClone = Instantiate(PreviewBlock, Vector3.zero, Quaternion.identity, this.transform);
            originalColor = PreviewClone.GetComponentInChildren<MeshRenderer>().material.color;
        }

        // See Order of Execution for Event Functions for information on FixedUpdate() and Update() related to physics queries
        public void Update()
        {
            //rate of building
            if (timer < interval)
            {
                timer += Time.deltaTime;
            }

            // Bit shift the index of the layer <<"" to get a bit mask
            int layerMask = 1 << layersExcept;

            // This would cast rays only against colliders in layer <<"".
            // But instead we want to collide against everything except layer <<"". The ~ operator does this, it inverts a bitmask.
            layerMask = ~layerMask;

            RaycastHit hit;
            // Does the ray intersect any objects excluding the player layer
            if (Physics.Raycast(raySource.position, raySource.TransformDirection(Vector3.forward), out hit, range, layerMask))
            {
                
                PreviewClone.SetActive(true);

                //get transform from collider
                HitLocation = hit.collider.transform;

                //check if contains connector layer else put on ray impact point
                if (HitLocation.gameObject.layer == 3 && HitLocation.tag == "Connector")
                {
                    //find preview clone and move to HitLocation
                    PreviewClone.transform.position = HitLocation.position;
                    PreviewClone.transform.rotation = HitLocation.rotation;
                    PreviewClone.transform.gameObject.GetComponentInChildren<MeshRenderer>().material.color = originalColor;

                    //build & reset cooldown, deplete inventory
                    if (Input.GetKey(BuildButton) && timer > interval)
                    {

                        timer = 0;

                        Instantiate(Block, HitLocation.position, HitLocation.rotation);

                        ItemSlot.coTempo--;

                        counter.text = ItemSlot.coTempo.ToString();

                        ItemSlot.deplete = true;

                    }
                }
                else
                {
                    //move to hitpoint with hitted transform rotation
                    PreviewClone.transform.position = hit.point; //+ new Vector3(0, 0.5625f);
                    PreviewClone.transform.rotation = HitLocation.rotation;
                    PreviewClone.transform.gameObject.GetComponentInChildren<MeshRenderer>().material.color = Color.red;
                    
                    /*
                    //place & reset cooldown, deplete inventory
                    // if (Input.GetKey(BuildButton) && timer > interval)
                    // {

                    //     timer = 0;

                    //     badPlace = Instantiate(Block, hit.point, HitLocation.rotation);

                    //     badPlace.AddComponent<Rigidbody>().mass = 25;

                    //     Transform firstChild = badPlace.transform.GetChild(0);

                    //     for (int i = 0; i < firstChild.childCount; i++)
                    //     {
                    //         Destroy(firstChild.GetChild(i).gameObject);
                    //     }

                    //     ItemSlot.coTempo--;

                    //     counter.text = ItemSlot.coTempo.ToString();

                    //     ItemSlot.deplete = true;

                    // }
                    */
                }

            }
            else
            {
                //reset transform if did not hit
                PreviewClone.SetActive(false);
            }

            //update player UI counter
            counter.text = ItemSlot.coTempo.ToString();

        }
    }
}

