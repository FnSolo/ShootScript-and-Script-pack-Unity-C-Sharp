using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mineable : MonoBehaviour
{
    [Header("Mine settings")]
    public float durability = 100;
    [Header("Tags")]
    public string mineTag = "Miner";
    public float damage = 25;
    public string wrongTools = "Bullet";

    [Header("Destroy drop")]
    public GameObject drop;
    public Transform dropLocation;
    // non-inspector
    private float originalDurability;


    void Start()
    {
        originalDurability = durability;
    }

    // Update is called once per frame
    void Update()
    {

        if (durability <= 0)
        {
            Instantiate(drop, dropLocation.position, dropLocation.rotation);
            if (transform.parent.gameObject != null)
            {
                Destroy(transform.parent.gameObject);
            }
            else
            {
                Destroy(gameObject);
            }

        }

        //damage stages %
        if (GetComponent<MeshRenderer>())
        {
            GetComponent<MeshRenderer>().material.color = new Color(durability / originalDurability, durability / originalDurability, durability / originalDurability);
        }
        
    }

    private void OnTriggerEnter(Collider col)
    {
        if (col.tag == mineTag)
        {
            durability -= damage;
        }
    }
    private void OnCollisionEnter(Collision col)
    {
        if (col.collider.tag == mineTag)
        {
            durability -= damage;
        }

        if (col.collider.tag.Contains(wrongTools))
        {
            durability -= 1;
        }
    }

    //damage call for raycast attacking script
    public void Damage()
    {

        durability -= damage;

    }

}

