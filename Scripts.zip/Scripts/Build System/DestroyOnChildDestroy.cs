using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyOnChildDestroy : MonoBehaviour
{
    public GameObject Parent;
    private void OnDestroy() {
        Destroy(Parent);
        
    }
}
