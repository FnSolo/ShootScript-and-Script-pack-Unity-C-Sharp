using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class SuperCursorButton : MonoBehaviour
{
    [Header("Main and optional show buttons")]
    public KeyCode ShowCursor = KeyCode.Tab;
    public KeyCode ShowCursor2 = KeyCode.Backslash;
    public GameObject Crosshair;
    public SUPERCharacter.SUPERCharacterAIO OFFComponent;
    private bool ON = false;
    private float timer, interval = 0.01f;
    private void Start() {
        
    }
    void Update()
    {
        if(timer<interval){
        timer += Time.deltaTime;
        }
        
        if(Input.GetKeyDown(ShowCursor)|Input.GetKeyDown(ShowCursor2)&&timer>interval&&ON == false)
        {
            timer = 0;
            ON = true;
            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;
            Crosshair.SetActive(false);
            //GetComponent<StarterAssets.FirstPersonController>().enabled = false; wrong, freezes player (can be useful for single player)
            OFFComponent.enabled = false;
            
        }
        //Set Cursor to not be visible
        if(Input.GetKeyDown(ShowCursor)|Input.GetKeyDown(ShowCursor2)&&timer>interval&&ON == true)
        {
            timer = 0;
            ON = false;
            Cursor.visible = false;
            Cursor.lockState = CursorLockMode.Locked;
            Crosshair.SetActive(true);
            OFFComponent.enabled = true;
        }
        
    }

}
