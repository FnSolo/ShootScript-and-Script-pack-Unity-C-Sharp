The code is relatively small (~250 lines including empty spaces) and commented.
_________________________________________________________________________
Recommendations:

- The first audiosource in hierarchy will be used for shoot sound

- Put this script on GameObject that contains other parts of a gun
_________________________________________________________________________
Core features:

1. Minigun mode & sound cutter, ability to "spin up" on RMB. 
PlayOneShot long sound and cut on buttonUp & func via Animation.

2. Simple upwards XY Spread from Barrel & XYZ Recoil for Camera
(If your Character controller can't recover YZ, leave their "Rotate Camera" 0)

3. Other basic features that are well described in Headers & Serialized fields.

4. Comes with 2 strings for your animation bools.
You can write in what you want in inspector, rename all
occurences on Ctrl + F2 in your IDE if needed.
_________________________________________________________________________
Additional info:

Variables is in Privates, except "Prefab"s.

You can delete the "Demo" folder, it doesn't affect the script.
_________________________________________________________________________
Additional Credits: 

"Nokobot, Modern Guns - Handgun" Free Unity Asset,
for short SimpleShoot script, that
was used as basis and its bullet & casing in DemoScene.

Turbosquid website for free Minigun model By AlexanderKokorin.