using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class AudioOnCollision : MonoBehaviour
{
    private new AudioSource audio;
    public bool playInsteadOfPlayOneShot;
    [Tooltip("Skips half collisions")] public bool allowSkips;

    private void Start()
    {
        audio = GetComponent<AudioSource>();
    }
    private void Update()
    {

    }
    private void OnCollisionEnter(Collision collision)
    {
        if (!playInsteadOfPlayOneShot)
        {
            if (!allowSkips)
            {
                audio.PlayOneShot(audio.clip);
            }
            else
            {
                if (Random.Range(1, 2) > 1)
                {
                    audio.PlayOneShot(audio.clip);
                }
            }

        }
        else
        {
            if (!allowSkips)
            {
                audio.Play();
            }
            else
            {
                if (Random.Range(1, 2) > 1)
                {
                    audio.Play();
                }
            }

        }

    }

}
