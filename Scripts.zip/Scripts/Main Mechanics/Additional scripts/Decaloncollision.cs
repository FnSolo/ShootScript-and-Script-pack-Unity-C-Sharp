using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Decaloncollision : MonoBehaviour
{
    [Tooltip("Be sure your prefab suits object in '0' Transforms")] public GameObject Bullethole;
    [Tooltip("Be sure your prefab suits object in '0' Transforms")] public GameObject Debris;
    [Tooltip("Be sure your prefab suits object in '0' Transforms")] public GameObject Sound_prefab;
    [Tooltip("Be sure your prefab suits object in '0' Transforms")] public Transform GetPos;
    [Tooltip("Destroy timer ONLY for decal")][SerializeField] private float time = 12;

    private Vector3 position;
    private Quaternion rotation;
    
    private void OnCollisionEnter(Collision col)
    {
            ContactPoint contact = col.GetContact(0);

            GameObject Decal = Instantiate(Bullethole, contact.point, GetPos.rotation, col.transform);
            Instantiate(Debris, GetPos.position, GetPos.rotation);
            Instantiate(Sound_prefab, GetPos.position, GetPos.rotation);
            Destroy(Decal, time);
}
}
