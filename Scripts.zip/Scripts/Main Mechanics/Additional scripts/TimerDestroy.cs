using UnityEngine;

public class TimerDestroy : MonoBehaviour
{
    [SerializeField] private float interval = 1f;
    public bool debug; public float time;
    void Start()
    {
        Destroy(gameObject, interval);
    }
    private void Update()
    {
        if (debug)
        {
            time += Time.deltaTime;
        }
    }

}
