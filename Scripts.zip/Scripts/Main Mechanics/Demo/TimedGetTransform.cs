using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimedGetTransform : MonoBehaviour
{
    public Transform get;

    public float timer;
    public float interval;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (timer < interval)
        {
            timer += Time.deltaTime;
        }
        else
        {
            timer = 0;
            gameObject.transform.rotation = get.transform.rotation;
            gameObject.transform.position = get.transform.position;
        }

    }
}
