﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Main
{
    public class ShootScript : MonoBehaviour
    {
        [Header("1. Prefab References")]
        public GameObject bulletPrefab;
        public GameObject casingPrefab;
        public GameObject muzzleFlashPrefab;

        [Header("2. Location References ")]
        [SerializeField] private Animator gunAnimator;
        [SerializeField] private Transform barrelLocation;
        [SerializeField] private Transform casingExitLocation;
        [SerializeField] private Transform muzzleLocation;
        [SerializeField] private Transform cameraRecoil;

        [Header("3. Physics")]
        [Tooltip("Bullet Speed")][SerializeField] private float shotPower = 500f;
        [Tooltip("Casing Ejection Speed, set low on low weights")][SerializeField] private float ejectPower = 1.5f;
        [Tooltip("Specify time to destory the casing object")][SerializeField] private float destroyTimer = 5f;
        [Tooltip("CasingRelease() and its reload on empty in Shoot() if you dont need animation precision")][SerializeField] bool casingInShoot = true;

        [Header("Rounds per minute (Interval is Readonly, use RPM)")]
        [Tooltip("Keeps animate, but calls Shoot() on click/hold instead. Remove Shoot() event in animation ")][SerializeField] bool preciseFireRate;
        [Tooltip("Wait RestrictShoot(), AllowShoot() event call, useful when using spinToShoot")][SerializeField] bool waitPermission = false;
        [Tooltip("Combines with 'wait' to achieve restriction while gun's clipping, casts from camera")][SerializeField] bool wallCheck = true;
        [SerializeField] float checkDistance = 0.444f;
        [SerializeField] LayerMask checkMask = default;
        [Tooltip("Classic Rounds per minute")][SerializeField] private float RPM = 1200;
        [Tooltip("Time already passed")][SerializeField] private float timer = 1f;
        [SerializeField] float interval;

        [Header("4. Recoil, X's inverted")]
        [Tooltip("Uses * Time.deltaTime to smooth")][SerializeField] private float rotateCameraX = 500;
        [Tooltip("Uses * Time.deltaTime to smooth")][SerializeField] private float rotateCameraY = 11;
        [Tooltip("Uses * Time.deltaTime to smooth")][SerializeField] private float rotateCameraZ = 111;
        [Tooltip("Assings new local quaternion, then resets")][SerializeField] private float shakeBarrelX = 0.05f, shakeBarrelBothY = 0.05f;

        [Header("5. Ammo & Clip size")]
        public float ammo = 90;
        [SerializeField] float clip = 7;
        [Tooltip("Will assign on Start() if <= 0")][SerializeField] float currentClip;

        [Header("6. Animation bools & Fire mode")]
        [Tooltip("Ignore timer & RoundsPerMinuteToInterval, work on KeyDown")][SerializeField] bool semiAuto = false;
        [Tooltip("Enables animation & Shoot() on its event")][SerializeField] bool animate = true;
        [SerializeField] string Fire = "Fire";
        [SerializeField] KeyCode fireKey = KeyCode.Mouse0;
        [Tooltip("Enables Spin anim bool. Make Fire transition from its Animator state.")][SerializeField] private bool spinToShoot = false;
        [SerializeField] private string Spin = "Spin";
        [SerializeField] KeyCode secondKey = KeyCode.Mouse1;
        [SerializeField] string Reload = "Reload";
        [SerializeField] KeyCode reloadKey = KeyCode.R;
        [Tooltip("SetBool true when gun is clipping")][SerializeField] string Clipping = "Clipping";

        [Header("7. Sound")]

        [Header("Minigun mode (Long sound cutter)")]
        [Tooltip("Cut immediately on Up, useful for high rate & looped")][SerializeField] private bool minigunMode = true;

        [Tooltip("Reached cuts in Shoot()")][SerializeField] float cut = 2.30208f;
        [Tooltip("Time already passed")][SerializeField] private float cutTimer;
        [Space()]
        [Tooltip("Pitch randoms -5%. Without its event is optionable")][SerializeField] AudioSource spinUp;
        [Tooltip("Fire or 'Spin' for it finished. Optionable")][SerializeField] AudioSource spinFinish;
        [Tooltip("Without its event is optionable")][SerializeField] AudioSource reloadSound;
        [Tooltip("Dry/empty fire. Without its event is optionable")][SerializeField] AudioSource emptySound;
        [Tooltip("When gun is ready. Optionable")][SerializeField] AudioSource reloadedSound;

        [Header("Randomize main sound")]
        [Tooltip("Disabled in minigun mode")][SerializeField] float randomizeUp = 0.00f;
        [SerializeField] float randomizeDown = 0.05f;
        [SerializeField] float origPitch = 1;
        private new AudioSource audio;
        private AudioSource[] allAudioSources;
        Quaternion resetRecoil;
        void StopAllAudio()
        {
            allAudioSources = FindObjectsOfType(typeof(AudioSource)) as AudioSource[];
            foreach (AudioSource audioS in allAudioSources)
            {
                audioS.Stop();
            }
        }

        //initiliazation
        void Start()
        {
            if (barrelLocation == null)
                barrelLocation = transform;

            if (gunAnimator == null)
                gunAnimator = GetComponentInChildren<Animator>();

            if (currentClip <= 0)
                currentClip = clip;

            audio = GetComponent<AudioSource>();

            resetRecoil = barrelLocation.localRotation;
        }

        void Update()
        {
            if (wallCheck)
            {
                ObsctacleCheck();
            }

            if (interval != RoundsPerMinuteToInterval(RPM))
            {
                interval = RoundsPerMinuteToInterval(RPM);
            }
            #region Input & SetBools, timers, recoil resetters, etc.
            //Reload, SetBool false is in function for Animation event below Update() & Sound animation events
            if (Input.GetKeyDown(reloadKey))
            {
                if (animate)
                    gunAnimator.SetBool(Reload, true);
            }
            //rate of fire
            if (timer < interval)
                timer += Time.deltaTime;

            #region spinToShoot, can be used in other prepare-to-shoot, when anim clip setupped to play once
            //Play on Get, stop on 'Up'  corresponding Spin animation bool animation
            if (spinToShoot)
            {
                //Resrict if already firing to avoid sound overlap
                if (Input.GetKey(secondKey) && !Input.GetKey(fireKey))
                    gunAnimator.SetBool(Spin, true);

                if (Input.GetKeyUp(secondKey))
                    gunAnimator.SetBool(Spin, false);
            }
            #endregion

            //Semi-automatic firing mode & sound timer preparation
            if (Input.GetKeyDown(fireKey) && timer >= interval)
            {
                //recoil reset, prevents transform distortion
                barrelLocation.localRotation = resetRecoil;

                if (semiAuto)
                {
                    if (animate)
                        gunAnimator.SetBool(Fire, true);

                    if (preciseFireRate | !animate)
                        Shoot();
                }

                //Gets the main audio ready to cut in Shoot(), main if Input doesn't contain fire mode check because of it
                if (minigunMode)
                    cutTimer = 99;
            }

            if (minigunMode)
            {
                if (cutTimer <= cut)
                    cutTimer += Time.deltaTime;

                if (currentClip <= 0 && animate)
                    gunAnimator.SetBool(Spin, false);
            }

            //Automatic firing mode
            if (Input.GetKey(fireKey) && timer >= interval && !semiAuto && currentClip > 0)
            {
                if (preciseFireRate | !animate && !semiAuto)
                { Shoot(); }

                //Automatic shot made, reset rate of fire timer
                timer = 0;
                if (animate == true)
                    //Calls animation on the gun that has the relevant animation events that will fire
                    gunAnimator.SetBool(Fire, true);

                //
                if (currentClip <= 0 && animate)
                    gunAnimator.SetBool(Fire, false);
            }

            if (Input.GetKeyUp(fireKey))
            {
                if (animate == true)
                    gunAnimator.SetBool(Fire, false);
                //Minigun mode, cut shoot sound on Up
                if (minigunMode)
                    audio.Stop();

                barrelLocation.localRotation = resetRecoil;
            }
        }
        #endregion Input & SetBools, timers, recoil resetters, etc.

        #region Sound animation events

        // Reload sound
        void ReloadSound()
        {
            reloadSound.Play();
        }
        void EmptySound()
        {
            emptySound.Play();
        }

        // Cut sound on function for robustness and both modes, starts spinFinish audio if any, stops other
        void CutMainSound_PlayFinish()
        {
            audio.Stop();
            if (spinUp)
                spinUp.Stop();

            if (spinFinish)
                spinFinish.Play();

            if (reloadSound)
                reloadSound.Stop();
        }

        // spinUp PlayOneShot func stops spinFinish, for quick transition from finishing state
        void SpinUp()
        {
            spinUp.pitch = Random.Range(0.95f, 1.0f);
            spinUp.PlayOneShot(spinUp.clip);
            if (spinFinish)
                spinFinish.Stop();
        }

        // Extra, cut spinUp sound
        void SpinUpStop()
        {
            spinUp.Stop();
        }

        // Extra, cut main sound, useful if Shoot() is not called on 1st animation frame
        void CutMainSound()
        {
            audio.Stop();
        }

        #endregion Sound animation events

        void AllowShoot()
        {
            waitPermission = false;
        }
        void RestrictShoot()
        {
            waitPermission = true;
        }

        // SetsBool Reload false, "Reloaded" for Animation event.
        void Reloaded()
        {
            gunAnimator.SetBool(Reload, false);

            float reloadAmount = Mathf.Min(clip - currentClip, ammo);
            if (ammo > 0)
            {
                ammo -= reloadAmount;
                currentClip += reloadAmount;
            }

            if (reloadedSound)
                reloadedSound.Play();
        }

        // This function creates the bullet behavior
        void Shoot()
        {
            // Magazine capacity check
            if (currentClip > 0 && !waitPermission)
            {
                // Will request reload on currentClip <= 0
                if (casingInShoot)
                    CasingRelease();

                // sound
                currentClip--;
                if (minigunMode)
                {
                    if (cutTimer >= cut)
                    {
                        cutTimer = 0;
                        audio.pitch = Random.Range(origPitch - randomizeDown, origPitch);
                        audio.PlayOneShot(audio.clip);
                    }
                }
                else
                {
                    audio.pitch = Random.Range(origPitch - randomizeDown, origPitch + randomizeUp);
                    audio.PlayOneShot(audio.clip);
                }


                // recoil
                barrelLocation.localRotation = new Quaternion(Random.Range(0f, -shakeBarrelX), Random.Range(-shakeBarrelBothY, shakeBarrelBothY), barrelLocation.localRotation.z, barrelLocation.localRotation.w);
                cameraRecoil.Rotate(-rotateCameraX * Time.deltaTime, rotateCameraY * Time.deltaTime, rotateCameraZ * Time.deltaTime);

                if (muzzleFlashPrefab)
                {
                    // Create the muzzle flash
                    GameObject tempFlash;
                    tempFlash = Instantiate(muzzleFlashPrefab, muzzleLocation.position, muzzleLocation.rotation);

                    // Destroy the muzzle flash effect
                    Destroy(tempFlash, destroyTimer);

                }

                // Cancels if there's no bullet prefeb
                if (!bulletPrefab)
                { return; }

                // Create a bullet and add force on it in direction of the barrel
                Instantiate(bulletPrefab, barrelLocation.position, barrelLocation.rotation).GetComponent<Rigidbody>().AddForce(barrelLocation.forward * shotPower);

                //recoil reset
                barrelLocation.localRotation = resetRecoil;

                //check spinUp field & stop sound on Shoot()
                if (spinUp)
                    spinUp.Stop();
            }

            if (currentClip <= 0 && !waitPermission) // Play dry fire, stop shoot sound if minigun mode
            {
                // Reload the gun if ammo left, request reload 
                if (casingInShoot)
                    CasingRelease();

                if (emptySound)
                    emptySound.Play();

                if (minigunMode)
                    audio.Stop();
            }
        }

        //This function creates a casing at the ejection slot
        void CasingRelease()
        {
            if (currentClip > 0)
            {
                //Cancels function if ejection slot hasn't been set or there's no casing
                if (!casingExitLocation || !casingPrefab)
                { return; }

                //Create the casing
                GameObject tempCasing;
                tempCasing = Instantiate(casingPrefab, casingExitLocation.position, casingExitLocation.rotation) as GameObject;
                //Add force on casing to push it out
                tempCasing.GetComponent<Rigidbody>().AddExplosionForce(Random.Range(ejectPower * 0.7f, ejectPower), (casingExitLocation.position - casingExitLocation.right * 0.3f - casingExitLocation.up * 0.6f), 1f);
                //Add torque to make casing spin in random direction
                tempCasing.GetComponent<Rigidbody>().AddTorque(new Vector3(0, Random.Range(100f, 500f), Random.Range(100f, 1000f)), ForceMode.Impulse);

                //Destroy casing after X seconds
                Destroy(tempCasing, destroyTimer);
            }
            else
            {
                if (animate && ammo > 0)
                {
                    gunAnimator.SetBool(Reload, true); gunAnimator.SetBool(Fire, false);
                }

            }
        }

        // gun clipping check,
        void ObsctacleCheck()
        {
            RaycastHit hit;
            if (Physics.Raycast(cameraRecoil.position, cameraRecoil.TransformDirection(Vector3.forward), out hit, checkDistance, checkMask))
            {
                Debug.DrawRay(cameraRecoil.position, cameraRecoil.TransformDirection(Vector3.forward) * hit.distance, Color.yellow);

                waitPermission = true;

                StopAllAudio(); cutTimer = 99;

                if (animate)
                    gunAnimator.SetBool(Clipping, true);
            }
            else
            {
                Debug.DrawRay(cameraRecoil.position, cameraRecoil.TransformDirection(Vector3.forward) * checkDistance, Color.white);



                if (animate)
                    gunAnimator.SetBool(Clipping, false);
                else waitPermission = false;
            }


        }

        //Calculator for convenience, per minute to 1 shot interval
        float RoundsPerMinuteToInterval(float perMinute)
        {
            float ShotsPerSecond;
            ShotsPerSecond = perMinute / 60;
            float shotInterval;
            shotInterval = ShotsPerSecond / (ShotsPerSecond * ShotsPerSecond);
            return shotInterval;
        }

        //debug GUI\counters
        private void OnGUI()
        {
            GUILayout.Label("Clip: " + currentClip + " Ammo: " + ammo);
        }

    }
}