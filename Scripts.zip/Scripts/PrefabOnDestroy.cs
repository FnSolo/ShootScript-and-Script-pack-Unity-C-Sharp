using UnityEngine;

public class PrefabOnDestroy : MonoBehaviour
{

    public GameObject Prefab;
    private void OnDestroy() 
    {
        if(!this.gameObject.scene.isLoaded) return;
        Instantiate(Prefab, gameObject.transform.position, gameObject.transform.rotation);

    }
}
